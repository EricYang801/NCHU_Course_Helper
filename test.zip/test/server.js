const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(cors());
app.use(compression()); // 啟用 gzip 壓縮

// 設置請求限制
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15分鐘
    max: 100 // 限制每個 IP 15分鐘內最多 100 個請求
});
app.use('/api/', limiter);

// 設置緩存策略
app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
        res.set('Cache-Control', 'no-cache');
    } else {
        res.set('Cache-Control', 'public, max-age=3600');
    }
    next();
});

// 檢查必要文件
const coursesPath = path.join(__dirname, 'data', 'courses.json');

// 提供靜態文件
app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: '1h',
    etag: true
}));

// 緩存課程資料
let coursesCache = null;
let lastCacheTime = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5分鐘快取

async function loadCoursesData() {
    try {
        if (coursesCache && (Date.now() - lastCacheTime < CACHE_DURATION)) {
            return coursesCache;
        }

        const rawData = await fs.readFile(coursesPath, 'utf8');
        const data = JSON.parse(rawData);
        

        if (!data.course || !Array.isArray(data.course)) {
            throw new Error('課程數據格式錯誤');
        }

        // 移除過濾條件，先看看完整的數據
        const validCourses = data.course.map(course => ({
            code: course.code,
            title: course.title,
            title_parsed: course.title_parsed,
            professor: course.professor,
            time: course.time,
            time_parsed: course.time_parsed,
            for_dept: course.for_dept,
            obligatory: course.obligatory,
            credits: course.credits,
            language: course.language,
            class: course.class,
            url: course.url,
            note: course.note
        }));

        coursesCache = validCourses;
        lastCacheTime = Date.now();
        return validCourses;
    } catch (error) {
        console.error('讀取課程數據失敗:', error);
        throw error;
    }
}

// API 路由
app.get('/api/courses', async (req, res) => {
    try {
        const courses = await loadCoursesData();
        
        // 分頁處理
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10000;
        const start = (page - 1) * limit;
        const end = start + limit;
        
        const paginatedCourses = courses.slice(start, end);
        
        res.json({
            course: paginatedCourses,
            total: courses.length,
            page,
            totalPages: Math.ceil(courses.length / limit),
            currentCount: paginatedCourses.length,  // 加入當前回傳的課程數
            start,  // 加入開始索引
            end,    // 加入結束索引
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('處理課程數據請求失敗:', error);
        res.status(500).json({ 
            error: '無法獲取課程資料',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// 搜尋 API
app.get('/api/courses/search', async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) {
            return res.status(400).json({ error: '請提供搜尋關鍵字' });
        }

        const courses = await loadCoursesData();
        const keywords = q.toLowerCase().split(/\s+/);
        
        const filtered = courses.filter(course => {
            const searchText = [
                course.title_parsed?.zh_TW,
                course.title_parsed?.en_US,
                course.title,
                course.professor,
                course.for_dept,
                course.code
            ].filter(Boolean).join(' ').toLowerCase();
            
            return keywords.every(keyword => searchText.includes(keyword));
        });

        res.json({
            course: filtered,
            total: filtered.length,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('處理課程搜尋請求失敗:', error);
        res.status(500).json({ 
            error: '搜尋失敗',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// 處理 404 錯誤
app.use((req, res) => {
    res.status(404).json({
        error: '找不到頁面',
        path: req.path,
        timestamp: new Date().toISOString()
    });
});

// 錯誤處理中間件
app.use((err, req, res, next) => {
    console.error('應用程式錯誤:', err);
    res.status(500).json({
        error: '伺服器錯誤',
        message: err.message,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
        timestamp: new Date().toISOString()
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`伺服器運行於 port ${PORT}`);
}); 